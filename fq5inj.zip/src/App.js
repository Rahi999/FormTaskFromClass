import "./styles.css";
import Form from "./components/Form"
import Ref from './components/Ref'

export default function App() {



  return (
    <div className="App">

        {/* <Form/> */}
        <Ref />
    </div>
  );
}
